/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <omp.h>
#include <time.h>
#include <stdlib.h>

int busquedaMaximo (int *a, int n);

int main ()
{
    srand(time(NULL));
    int a[10];
    for (int i=0; i<10;i++){
        a[i]=rand()%90;
        printf("%i ", a[i]);
    }
    printf("\n%i", busquedaMaximo(a, 10));
}

//secuencial
/*
int busquedaMaximo (int *a, int n){
    int max, i;
    max=a[0];
    for(i=1;i<n;i++){
        if (a[i]>max){
            max=a[i];
        }
    }
    return max;
}*/

//paralela
int busquedaMaximo (int *a, int n){
    int max, i;
    max=a[0];
    #pragma omp parallel for
    for(i=1;i<n;i++){
        if (a[i]>max){
            #pragma omp critical
            {
                if (a[i]>max){
                    max=a[i];
                }
            }
        }
    }
    return max;
}
