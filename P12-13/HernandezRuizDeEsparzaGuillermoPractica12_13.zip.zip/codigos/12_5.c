/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <omp.h>
int main( )
{
    int a[5], i;
    #pragma omp parallel
    {
        #pragma omp for
        for (i = 0; i < 5; i++) //i[0] = 0 i[1] = 1  i[2] = 4  i[3] = 9  i[4] = 16
            a[i] = i * i;

        #pragma omp single
        for (i = 0; i < 5; i++)
            printf("a[%d] = %d\n", i, a[i]);
        #pragma omp barrier

        #pragma omp for
            for (i = 0; i < 5; i++)
                a[i] += i;  //i[0] = 0 i[1] = 2  i[2] = 6  i[3] = 12  i[4] = 20
                

 }
} 