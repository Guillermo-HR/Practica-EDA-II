/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>
/*
int main()
{
    srand(time(NULL));
    int nra=500, nca=500, ncb=500;
    int a[nra][nca], b[nca][ncb], c[nra][ncb];
    int i,j,k;
    for(i=0;i<nra;i++){
        for(j=0;j<ncb;j++){
            c[i][j]=0;
        }
    }
    for(i=0;i<nra;i++){
        for(j=0;j<nca;j++){
            a[i][j]=rand()%5;
        }
    }
    for(i=0;i<nca;i++){
        for(j=0;j<ncb;j++){
            b[i][j]=rand()%5;
        }
    }
    double inicio=omp_get_wtime();
    for (i=0;i<nra;i++){
        for (j=0;j<ncb;j++){
            for (k=0;k<nca;k++){
                c[i][j]+=a[i][k]*b[k][j];
            }
        }
    }
    double fin=omp_get_wtime();
    printf("Tiempo: %lf",fin-inicio);
    return 0;
}
*/
int main()
{
    srand(time(NULL));
    int nra=2, nca=3, ncb=3;
    int a[nra][nca], b[nca][ncb], c[nra][ncb];
    int i,j,k;
    #pragma omp parallel for
    for(i=0;i<nra;i++){
        for(j=0;j<ncb;j++){
            c[i][j]=0;
        }
    }
    for(i=0;i<nra;i++){
        for(j=0;j<nca;j++){
            a[i][j]=rand()%5;
        }
    }
    for(i=0;i<nca;i++){
        for(j=0;j<ncb;j++){
            b[i][j]=rand()%5;
        }
    }
    double inicio=omp_get_wtime();
    #pragma omp parallel for private (j,k)
    for (i=0;i<nra;i++){
        for (j=0;j<ncb;j++){
            for (k=0;k<nca;k++){
                c[i][j]+=a[i][k]*b[k][j];
            }
        }
    }
    double fin=omp_get_wtime();
    printf("Tiempo: %lf",fin-inicio);
    return 0;
}


