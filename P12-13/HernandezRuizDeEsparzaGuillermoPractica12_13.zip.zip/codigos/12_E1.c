/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <omp.h>

void realizarUnTrabajo(int A, int B);

int main()
{
    int A=1, B=2, C=3;
    #pragma omp parallel shared (A, B, C)
    {
        realizarUnTrabajo(A, B);
        printf("Procesado A y B\tHilo: %i\n", omp_get_thread_num());
        #pragma omp barrier //esperan
        realizarUnTrabajo(B, C);
        printf("Procesado B y C\tHilo: %i\n", omp_get_thread_num());
    }

    return 0;
}

void realizarUnTrabajo(int A, int B){
    
}