/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<omp.h>
#define N 100000
float a[N], b[N], c[N],d[N], e[N],f[N];
void operaciones();
int main () {
    double empezar,terminar;
    int i,j;
    
    for (i=0; i < N; i++)
        a[i] = b[i] = i * 1.0;

    empezar=omp_get_wtime( );
    operaciones();
    terminar=omp_get_wtime();
    printf("Tiempo=%lf\n",terminar-empezar);
}

//sections
void operaciones(){
    int i,j;
    #pragma omp sections
    {
        #pragma omp section
            for(i=0; i<N; i++)
                c[i]=a[i]+b[i];
        #pragma omp section
            for(j=0; j<N; j++)
                d[j]=e[j]+f[j];
    }
}

//for
/*
void operaciones(){
    int i, j;
    #pragma omp for
    for(i=0; i<N; i++)
        c[i]=a[i]+b[i];
    #pragma omp for 
    for(j=0; j<N; j++)
        d[j]=e[j]+f[j];
}*/
