/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <omp.h>

void todosRalizanUnasActividades(int A);
void ActividadE_S(int A);
void RealizanMasActividades(int A);

int main()
{
    #pragma omp parallel
    {
        todosRalizanUnasActividades(omp_get_thread_num());
        #pragma omp single
        {
            ActividadE_S(omp_get_thread_num());
        } // Hilos esperan
        RealizanMasActividades(omp_get_thread_num());
    }

    return 0;
}

void todosRalizanUnasActividades(int A){
    printf("todosRalizanUnasActividades\tHilo: %i\n", A);
}
void ActividadE_S(int A){
    printf("ActividadE_S()\tHilo: %i\n", A);
}
void RealizanMasActividades(int A){
    printf("RealizanMasActividades()\tHilo: %i\n", A);
}
