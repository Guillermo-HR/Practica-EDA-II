import java.util.Scanner;

public class Menu {
    String[] opcionesG;
    ArbolBin arbol;
    ArbolBinBusq arbolBusq;
    BTree arbolB;

    public Menu() {
        opcionesG = new String[4];
        opcionesG[0] = "Salir";
        opcionesG[1] = "Arbol Binario";
        opcionesG[2] = "Arbol Binario de busqueda";
        opcionesG[3] = "Arbol B";
        arbol = null;
        arbolBusq = null;
        arbolB = null;
    }

    public void menuGeneral() {
        int opcion;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println(" ------------------\n|   Menu General   |\n ------------------");
            for (int i = 0; i < opcionesG.length; i++)
                System.out.println(i + ". " + opcionesG[i]);
            try {
                System.out.print("Opcion: ");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 0:
                        System.out.println("Saliendo...");
                        break;
                    case 1:
                        menuArbolBinario();
                        break;
                    case 2:
                        menuArbolBinarioBusqueda();
                        break;
                    case 3:
                        menuArbolB();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        opcion = -1;
                        break;
                }
            } catch (Exception e) {
                System.out.println("Valor no valido");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    private void menuArbolBinario() {
        int opcion;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println(" ------------------------\n|   Menu Arbol Binario   |\n ------------------------");
            System.out.println("0. Regresar\n1. Crear arbol\n2. Agregar dato\n3. Eliminar dato\n4. Imprimir arbol (BFS)\n5. Notacion prefija (preorden)\n6. Notacion infija (inorden)\n7. Notacion postfija (postorden)");
            try {
                System.out.print("Opcion: ");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 0:
                        System.out.println("Regresando...");
                        break;
                    case 1:
                        arbol = new ArbolBin();
                        System.out.println("Se creo el arbol");
                        break;
                    case 2:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        if (arbol.root == null) {
                            System.out.println("Ingrese el dato a agregar: ");
                            int dato = sc.nextInt();
                            arbol.root = new Nodo(dato);
                            break;
                        }
                        System.out.println("Quien va a ser el padre?");
                        int padreValue = sc.nextInt();
                        if (!arbol.buscar(padreValue)) {
                            System.out.println("El padre no existe");
                            break;
                        }
                        Nodo padre = arbol.buscarNodo(padreValue);
                        if (padre.izq != null && padre.der != null) {
                            System.out.println("El padre ya tiene dos hijos");
                            break;
                        }
                        System.out.println("Quien va a ser el hijo? ");
                        int hijoValue = sc.nextInt();
                        if (arbol.buscar(hijoValue)) {
                            System.out.println("El hijo ya existe");
                            break;
                        }
                        System.out.print("Lados disponibles: ");
                        if (padre.izq == null)
                            System.out.print("izquierdo ");
                        if (padre.der == null)
                            System.out.print("derecho ");
                        System.out.println("\nIzquierdo(0) o derecho(1)? ");
                        int lado = sc.nextInt();
                        if (lado != 0 && lado != 1) {
                            System.out.println("Lado no valido");
                            break;
                        }
                        if (lado == 0 && padre.izq != null) {
                            System.out.println("El padre ya tiene un hijo izquierdo");
                            break;
                        }
                        if (lado == 1 && padre.der != null) {
                            System.out.println("El padre ya tiene un hijo derecho");
                            break;
                        }
                        Nodo hijo = new Nodo(hijoValue);
                        arbol.add(padre, hijo, lado);
                        System.out.println("Se agrego el hijo");
                        break;
                    case 3:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Que dato desea eliminar?");
                        int dato = sc.nextInt();
                        arbol.eliminarNodo(dato);
                        break;
                    case 4:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbol.breadthFrist();
                        break;
                    case 5:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbol.preorden();
                        break;
                    case 6:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbol.inorden();
                        break;
                    case 7:
                        if (arbol == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbol.postorden();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        opcion=-1;
                        break;
                }
            } catch (Exception e) {
                System.out.println("Valor no valido");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    private void menuArbolBinarioBusqueda() {
        int opcion;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println(" ------------------------------------\n|   Menu Arbol Binario de Busqueda   |\n ------------------------------------");
            System.out.println("0. Regresar\n1. Crear arbol\n2. Agregar dato\n3. Eliminar dato\n4. Buscar dato\n5. Imprimir arbol (BFS)");
            int dato;
            try {
                System.out.print("Opcion: ");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 0:
                        System.out.println("Regresando...");
                        break;
                    case 1:
                        arbolBusq = new ArbolBinBusq();
                        System.out.println("Se creo el arbol");
                        break;
                    case 2:
                        if (arbolBusq == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Ingrese el dato a agregar: ");
                        dato = sc.nextInt();
                        arbolBusq.add(new Nodo(dato));
                        break;
                    case 3:
                        if (arbolBusq == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Que dato desea eliminar?");
                        dato = sc.nextInt();
                        arbolBusq.eliminarNodo(dato);
                        break;
                    case 4:
                        if (arbolBusq == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Que dato desea buscar?");
                        dato = sc.nextInt();
                        if (arbolBusq.buscar(dato))
                            System.out.println("El dato existe");
                        else
                            System.out.println("El dato no existe");
                        break;
                    case 5:
                        if (arbolBusq == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbolBusq.breadthFrist();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        opcion=-1;
                        break;
                }
            } catch (Exception e) {
                System.out.println("Valor no valido");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    private void menuArbolB(){
        int opcion;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println(" ----------------------\n|   Menu Arbol B      |\n ----------------------");
            System.out.println("0. Regresar\n1. Crear arbol\n2. Agregar dato\n3. Buscar dato\n4. Imprimir arbol");
            int dato;
            try {
                System.out.print("Opcion: ");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 0:
                        System.out.println("Regresando...");
                        break;
                    case 1:
                        System.out.println("Ingrese el orden del arbol: ");
                        int orden = sc.nextInt();
                        arbolB = new BTree(orden);
                        System.out.println("Se creo el arbol");
                        break;
                    case 2:
                        if (arbolB == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Ingrese el dato a agregar: ");
                        dato = sc.nextInt();
                        arbolB.add(dato);
                        break;
                    case 3:
                        if (arbolB == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        System.out.println("Que dato desea buscar?");
                        dato = sc.nextInt();
                        if (arbolB.find(dato))
                            System.out.println("El dato existe");
                        else
                            System.out.println("El dato no existe");
                        break;
                    case 4:
                        if (arbolB == null) {
                            System.out.println("Debe crear el arbol primero");
                            break;
                        }
                        arbolB.mostrarArbol();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        opcion=-1;
                        break;
                }
            } catch (Exception e) {
                System.out.println("Valor no valido");
                opcion = -1;
            }
        } while (opcion != 0);
    }
}
