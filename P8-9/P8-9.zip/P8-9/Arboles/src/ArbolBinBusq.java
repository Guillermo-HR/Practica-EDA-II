public class ArbolBinBusq extends ArbolBin{

    public ArbolBinBusq(Nodo root) {
        this.root = root;
    }

    public ArbolBinBusq() {
    }

    public ArbolBinBusq(int val) {
        root = new Nodo(val);
    }

    public void add(Nodo hijo){
        if(root==null){
            root=hijo;
        }else{
            Nodo actual=root;
            Nodo padre=null;
            while(actual!=null){
                padre=actual;
                if(hijo.valor<actual.valor){
                    actual=actual.izq;
                }else{
                    actual=actual.der;
                }
            }
            if(hijo.valor<padre.valor){
                padre.izq=hijo;
            }else{
                padre.der=hijo;
            }
        }
    }
}
