
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Edgar
 */
public class Pruebas {

    public static void main(String args[]) {
        /*
        // Ejercicio 1 b)
        ArbolBin arbol;
        Nodo n7 = new Nodo(7);
        Nodo n9 = new Nodo(9);
        Nodo n1 = new Nodo(1, n7, n9);
        Nodo n15 = new Nodo(15);
        Nodo n8 = new Nodo(8);
        Nodo n4 = new Nodo(4);
        Nodo n2 = new Nodo(2);
        Nodo n16 = new Nodo(16);
        Nodo n3 = new Nodo(3);

        arbol = new ArbolBin(n1);
        arbol.add(n7, n15, 0);
        arbol.add(n7, n8, 1);
        arbol.add(n9, n4, 0);
        arbol.add(n9, n2, 1);
        arbol.add(n15, n16, 1);
        arbol.add(n8, n3, 0);
        arbol.breadthFrist();
        */
        
        /*
        // Ejercicio 1 c, d, e)
        ArbolBin arbol2;
        Nodo n20=new Nodo(20);
        Nodo n72=new Nodo(72);
        Nodo n5 = new Nodo(5,n20, n72);
        Nodo n7 = new Nodo(7);
        Nodo n31 = new Nodo(31);
        Nodo n40 = new Nodo(40);
        Nodo n29 = new Nodo(29);
        Nodo n3 = new Nodo(3);
        Nodo n1 = new Nodo(1);
        Nodo n10 = new Nodo(10);
        Nodo n65 = new Nodo(65);

        arbol2 = new ArbolBin(n5);
        arbol2.add(n20, n7, 0);
        arbol2.add(n20, n31, 1);
        arbol2.add(n72, n40, 0);
        arbol2.add(n72, n29, 1);
        arbol2.add(n7, n3, 0);
        arbol2.add(n7, n1, 1);
        arbol2.add(n31, n10, 1);
        arbol2.add(n29, n65, 0);
        arbol2.breadthFrist();
        arbol2.eliminarNodo(20);
        arbol2.breadthFrist();
        arbol2.eliminarNodo(100);
        arbol2.breadthFrist();
        System.out.println("Existe el nodo 3:"+arbol2.buscar(3));
        System.out.println("Existe el nodo 65:"+arbol2.buscar(65));
        */
        /* 
        // Ejercicio 2
        ArbolBin arbol3;
        Nodo n65 = new Nodo(65);
        Nodo n25 = new Nodo(25);
        Nodo n5 = new Nodo(5,n65, n25);
        Nodo n30 = new Nodo(30);
        Nodo n10 = new Nodo(10);
        Nodo n60 = new Nodo(60);
        Nodo n55 = new Nodo(55);
        Nodo n35 = new Nodo(35);
        Nodo n50 = new Nodo(50);
        Nodo n40 = new Nodo(40);
        Nodo n15 = new Nodo(15);
        Nodo n20 = new Nodo(20);
        Nodo n45 = new Nodo(45);

        arbol3 = new ArbolBin(n5);
        arbol3.add(n65, n30, 0);
        arbol3.add(n25, n10, 0);
        arbol3.add(n30, n60, 0);
        arbol3.add(n30, n55, 1);
        arbol3.add(n10, n35, 1);
        arbol3.add(n55, n50, 0);
        arbol3.add(n55, n40, 1);
        arbol3.add(n35, n15, 0);
        arbol3.add(n50, n20, 0);
        arbol3.add(n50, n45, 1);
        arbol3.preorden();
        arbol3.inorden();
        arbol3.postorden();
        */
        /*
        // Ejercicio 3
        ArbolBinBusq arbol4;
        Nodo n60 = new Nodo(60);
        Nodo n20 = new Nodo(20);
        Nodo n100 = new Nodo(100);
        Nodo n10 = new Nodo(10);
        Nodo n50 = new Nodo(50);
        Nodo n80 = new Nodo(80);
        Nodo n110 = new Nodo(110);
        Nodo n15 = new Nodo(15);
        Nodo n90 = new Nodo(90);
        Nodo n105 = new Nodo(105);

        arbol4 = new ArbolBinBusq(n60);
        arbol4.add(n20);
        arbol4.add(n100);
        arbol4.add(n10);
        arbol4.add(n50);
        arbol4.add(n80);
        arbol4.add(n110);
        arbol4.add(n15);
        arbol4.add(n90);
        arbol4.add(n105);
        arbol4.breadthFrist();
        arbol4.eliminarNodo(60);
        arbol4.breadthFrist();
        */

        // Ejercicio 4
        Menu menu = new Menu();
        menu.menuGeneral();
        
    }
}
