public class Principal {
    public static void main(String[] args){
        // Crear un arreglo de 20 elementos con numeros entre 0 y 300
        int[] arreglo = new int[20];
        for(int i = 0; i < arreglo.length; i++){
            arreglo[i] = (int)(Math.random() * 300);
        }
        //imprime el arreglo original
        System.out.println("Arreglo original:");
        Utilerias.printArray(arreglo);
        //ordena el arreglo con el algoritmo de quicksort
        //Quicksort.QuickSort(arreglo, 0, arreglo.length - 1);
        //ordena el arreglo con el algoritmo de mergesort
        MergeSort mergeSort = new MergeSort();
        mergeSort.sort(arreglo, 0, arreglo.length - 1);
        //imprime el arreglo ordenado
        System.out.println("Arreglo ordenado:");
        Utilerias.printArray(arreglo);
    }
}
