#ifndef UTILIDADES_H_
#define UTILIDADES_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct
{
    float comparaciones;
    float intercambios;
    float inserciones;
    float suma;
} Contador;

void swap(int *a, int *b);
void printArray(int arr[], int size);
void printSubArray(int arr[], int low, int high);
void listaAleatoria(int *lista, int n);
void leerLista(int *lista, int n);
void imprimirResultados(int size, Contador *cont);

#endif