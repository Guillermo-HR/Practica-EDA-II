#ifndef ORDENAMIENTOS_H_
#define ORDENAMIENTOS_H_

#include "utilidades.h"

void selectionSort(int arreglo[], int n);
void insertionSort(int a[], int n);
void bubbleSort(int a[], int size);
void heapSort(int* A, int size);
void heapify(int* A, int i, int size);
void buildHeap(int* A, int size);
void quickSort(int arr[], int low, int high);
int partition (int arr[], int low, int high);
void mergeSort (int list[] , int p , int r );
void merge(int list[], int p, int q, int r);

void heapSortE4(int* A, int size, Contador *cont);
void heapifyE4(int* A, int i, int size, Contador *cont);
void quickSortE4(int arr[], int low, int high, Contador *cont);
int partitionE4(int arr[], int low, int high, Contador *cont);
void mergeSortE4(int list[] , int p , int r, Contador *cont);
void mergeE4(int list[], int p, int q, int r, Contador *cont);

#endif