#include "ordenamientos.h"

int main(){
    srand(time(NULL));
    int size=20, lista[size];
    for (int i=0; i<size; i++)
        lista[i]=rand()%1000;
    printf("\nAreglo original: ");
	printArray(lista, size);
    //EJER 1
    //heapSort(lista, size);
    //quickSort(lista, 0,size-1);
    //EJER 2
    mergeSort(lista, 0, size-1);
    printf("\nAreglo ordenado: ");
	printArray(lista, size);
}