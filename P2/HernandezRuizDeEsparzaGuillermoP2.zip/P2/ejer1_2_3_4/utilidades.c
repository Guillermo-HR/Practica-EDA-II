#include "utilidades.h"

void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

void printArray(int arr[], int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

void printSubArray(int arr[], int low, int high)
{
    int i;
    printf("Sub array :  ");
    for (i = low; i <= high; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

void listaAleatoria(int *lista, int n)
{
    for (int i = 0; i < n; i++)
        lista[i] = rand() % 1000;
}

void leerLista(int *lista, int n)
{
    system("clear");
    printf("Ingrese los datos de la lista\n");
    for (int i = 0; i < n; i++)
    {
        printf(">>");
        scanf("%d", &lista[i]);
    }
}

void imprimirResultados(int size, Contador *cont)
{
    printf("\n\n---Resultados---\n");
    printf("Datos ordenados: %d\n", size);
    printf("Metodo\t\tComparaciones\tIntercambios\tInserciones\tSuma\n");
    printf("heapSort\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f\n", cont[0].comparaciones, cont[0].intercambios, cont[0].inserciones, cont[0].suma);
    printf("quickSort\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f\n", cont[1].comparaciones, cont[1].intercambios, cont[1].inserciones, cont[1].suma);
    printf("mergeSort\t%0.0f\t\t%0.0f\t\t%0.0f\t\t%0.0f", cont[2].comparaciones, cont[2].intercambios, cont[2].inserciones, cont[2].suma);
    printf("\n\n---Resultados promedios---\n");
    printf("Datos ordenados: %d\n", size);
    printf("Metodo\t\tComparaciones\tIntercambios\tInserciones\tSuma\n");
    printf("heapSort\t%0.2f\t\t%0.2f\t\t%0.2f\t\t%0.2f\n", cont[0].comparaciones / 5, cont[0].intercambios / 5, cont[0].inserciones / 5, cont[0].suma / 5);
    printf("quickSort\t%0.2f\t\t%0.2f\t\t%0.2f\t\t%0.2f\n", cont[1].comparaciones / 5, cont[1].intercambios / 5, cont[1].inserciones / 5, cont[1].suma / 5);
    printf("mergeSort\t%0.2f\t\t%0.2f\t\t%0.2f\t\t%0.2f", cont[2].comparaciones / 5, cont[2].intercambios / 5, cont[2].inserciones / 5, cont[2].suma / 5);
}