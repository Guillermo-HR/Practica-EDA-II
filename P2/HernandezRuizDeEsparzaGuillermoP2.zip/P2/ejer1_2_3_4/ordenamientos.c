#include "ordenamientos.h"

void selectionSort(int arreglo[], int n)
{
	int indiceMenor, i, j;
	printf("\nSelection Sort\n");
	printf("arreglo original: ");
	printArray(arreglo, n);
	for (i = 0; i < n - 1; i++)
	{
		indiceMenor = i;
		for (j = i + 1; j < n; j++)
		{
			if (arreglo[j] < arreglo[indiceMenor])
				indiceMenor = j;
		}
		if (i != indiceMenor)
			swap(&arreglo[i], &arreglo[indiceMenor]);
		printf("\nIteracion numero %d \n", i + 1);
		printArray(arreglo, n);
	}
}

void insertionSort(int a[], int n)
{
	int i, j;
	int aux;
	printf("\nInsertion Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = 1; i < n; i++)
	{
		j = i;
		aux = a[i];
		while (j > 0 && aux < a[j - 1])
		{
			a[j] = a[j - 1];
			j--;
		}
		a[j] = aux;

		printf("\nIteracion numero %d \n", i);
		printArray(a, n);
	}
}

void bubbleSort(int a[], int size)
{
	int i, j, n, iteraciones = 1;
	int bandera;
	n = size;
	printf("\nBubble Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = n - 1; i > 0; i--)
	{
		bandera = 1;
		for (j = 0; j < i; j++)
		{
			if (a[j] > a[j + 1])
			{
				swap(&a[j], &a[j + 1]);
				bandera = 0;
			}
		}
		if (bandera)
		{
			printf("\nEl arreglo ya esta ordenado\t se termino en %i iteraciones\n", iteraciones);
			printArray(a, n);
			return;
		}
		printf("\nIteracion numero %d \n", iteraciones);
		iteraciones++;
		printArray(a, n);
	}
	iteraciones--;
}

int heapSize;
void heapSort(int *A, int size)
{
	buildHeap(A, size);
	int i, iteraciones = 1;
	for (i = size - 1; i > 0; i--)
	{
		swap(&A[0], &A[heapSize]);
		heapSize--;
		printf("Iteracion HS: %i\n", iteraciones);
		iteraciones++;
		printArray(A, size);
		heapify(A, 0, size);
	}
}

void heapify(int *A, int i, int size)
{
	int l = 2 * i + 1;
	int r = 2 * i + 2;
	int largest;

	if (l <= heapSize && A[l] > A[i])
		largest = l;
	else
		largest = i;
	if (r <= heapSize && A[r] > A[largest])
		largest = r;
	if (largest != i)
	{
		swap(&A[i], &A[largest]);
		printArray(A, size);
		heapify(A, largest, size);
	}
}

void buildHeap(int *A, int size)
{
	heapSize = size - 1;
	int i;
	for (i = (size - 1) / 2; i >= 0; i--)
	{
		heapify(A, i, size);
	}
	printf("Termin%c de construir el HEAP \n", 162);
}

void quickSort(int arr[], int low, int high)
{
	if (low < high)
	{
		int pi = partition(arr, low, high);
		printSubArray(arr, low, pi - 1);
		quickSort(arr, low, pi - 1);
		printSubArray(arr, pi + 1, high);
		quickSort(arr, pi + 1, high);
	}
}

int partition(int arr[], int low, int high)
{
	int pivot = arr[high];
	printf("Pivote: %d   \n ", pivot);
	int j, i = (low - 1);
	for (j = low; j <= high - 1; j++)
	{
		if (arr[j] <= pivot)
		{
			i++;
			swap(&arr[i], &arr[j]);
		}
	}
	swap(&arr[i + 1], &arr[high]);
	return (i + 1);
}

void mergeSort(int list[], int p, int r)
{
	printf("\nLista a ordenar: ");
	printSubArray(list, p, r);
	int q;
	if (p < r)
	{
		q = (p + r) / 2;
		mergeSort(list, p, q);
		mergeSort(list, q + 1, r);
		merge(list, p, q, r);
	}
}

void merge(int list[], int p, int q, int r)
{
	printf("\nListas a juntar: ");
	printSubArray(list, p, q);
	printf(" y ");
	printSubArray(list, q + 1, r);

	int list2[r - p + 1];

	int i, j, k;
	i = p;
	j = q + 1;
	k = 0;
	while (i <= q && j <= r)
	{
		if (list[i] < list[j])
			list2[k++] = list[i++];
		else
			list2[k++] = list[j++];
	}
	while (i <= q)
		list2[k++] = list[i++];
	while (j <= r)
		list2[k++] = list[j++];
	for (i = r; i >= p; i--)
		list[i] = list2[--k];
}
//
void heapSortE4(int *A, int size, Contador *cont)
{
	buildHeap(A, size);
	int i, iteraciones = 1;
	for (i = size - 1; i > 0; i--)
	{
		cont->intercambios++;
		swap(&A[0], &A[heapSize]);
		heapSize--;
		printf("Iteracion HS: %i\n", iteraciones);
		iteraciones++;
		printArray(A, size);
		heapifyE4(A, 0, size, cont);
	}
}

void heapifyE4(int *A, int i, int size, Contador *cont)
{
	int l = 2 * i + 1;
	int r = 2 * i + 2;
	int largest;

	if (l <= heapSize && A[l] > A[i])
	{
		cont->comparaciones += 3;
		largest = l;
	}
	else
	{
		if (l <= heapSize)
			cont->comparaciones += 3;
		else
			cont->comparaciones++;
		largest = i;
	}
	if (r <= heapSize && A[r] > A[largest])
	{
		cont->comparaciones += 3;
		largest = r;
	}
	else
	{
		if (r <= heapSize)
			cont->comparaciones += 3;
		else
			cont->comparaciones++;
	}
	cont->comparaciones++;
	if (largest != i)
	{
		cont->intercambios++;
		swap(&A[i], &A[largest]);
		printArray(A, size);
		heapifyE4(A, largest, size, cont);
	}
}

void quickSortE4(int arr[], int low, int high, Contador *cont)
{
	cont->comparaciones++;
	if (low < high)
	{
		int pi = partitionE4(arr, low, high, cont);
		printSubArray(arr, low, pi - 1);
		quickSortE4(arr, low, pi - 1, cont);
		printSubArray(arr, pi + 1, high);
		quickSortE4(arr, pi + 1, high, cont);
	}
}

int partitionE4(int arr[], int low, int high, Contador *cont)
{
	int pivot = arr[high];
	printf("Pivote: %d   \n ", pivot);
	int j, i = (low - 1);
	for (j = low; j <= high - 1; j++)
	{
		cont->comparaciones++;
		if (arr[j] <= pivot)
		{
			i++;
			cont->intercambios++;
			swap(&arr[i], &arr[j]);
		}
	}
	cont->intercambios++;
	swap(&arr[i + 1], &arr[high]);
	return (i + 1);
}

void mergeSortE4(int list[], int p, int r, Contador *cont)
{
	printf("\nLista a ordenar: ");
	printSubArray(list, p, r);
	int q;
	cont->comparaciones++;
	if (p < r)
	{
		q = (p + r) / 2;
		mergeSortE4(list, p, q, cont);
		mergeSortE4(list, q + 1, r, cont);
		mergeE4(list, p, q, r, cont);
	}
}

void mergeE4(int list[], int p, int q, int r, Contador *cont)
{
	printf("\nListas a juntar: ");
	printSubArray(list, p, q);
	printf("y ");
	printSubArray(list, q + 1, r);

	int list2[r - p + 1];

	int i, j, k;
	i = p;
	j = q + 1;
	k = 0;

	if (i > q)
		cont->comparaciones++;
	else
	{
		while (i <= q && j <= r)
		{
			cont->comparaciones += 3;
			cont->comparaciones++;
			if (list[i] < list[j])
				list2[k++] = list[i++];
			else
				list2[k++] = list[j++];
		}
		if (i<=q)
			cont->comparaciones+=3;
		else
			cont->comparaciones++;
	}
	if (i > q)
		cont->comparaciones++;
	else
	{
		while (i <= q)
		{
			cont->comparaciones++;
			list2[k++] = list[i++];
		}
		cont->comparaciones++;
	}
	if (j > r)
		cont->comparaciones++;
	else
	{
		while (j <= r)
		{
			cont->comparaciones++;
			list2[k++] = list[j++];
		}
		cont->comparaciones++;
	}
	for (i = r; i >= p; i--)
		list[i] = list2[--k];
}
