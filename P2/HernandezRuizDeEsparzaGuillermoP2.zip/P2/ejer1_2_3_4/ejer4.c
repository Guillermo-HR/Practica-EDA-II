#include "ordenamientos.h"

int main()
{
    srand(time(NULL));
    int size;
    do // Pide el tamaño del arreglo
    {
        system("clear");
        printf("---Tamaño arreglo---\n");
        printf(">>Ingrese la cantidad de elementos del arreglo: ");
        scanf("%d", &size);
    } while (size < 1);
    int lista[size], contador, ordenamiento = 1;
    Contador cont[3];
    for (int i = 0; i < 3; i++)
    {
        cont[i].comparaciones = 0;
        cont[i].intercambios = 0;
        cont[i].inserciones = 0;
        cont[i].suma = 0;
    }
    /*
        cont[0], ordenamiento = 1 -> heapSort
        cont[1], ordenamiento = 2 -> quickSort
        cont[2], ordenamiento = 3 -> mergeSort
    */
    for (int i = 1; i < 16; i++)
    {
        listaAleatoria(lista, size);
        if (ordenamiento == 1)
        {
            printf("\nAreglo original: ");
            printArray(lista, size);
            heapSortE4(lista, size, &cont[0]);
            printf("\nAreglo ordenado: ");
            printArray(lista, size);
        }
        else if (ordenamiento == 2)
        {
            printf("\nAreglo original: ");
            printArray(lista, size);
            quickSortE4(lista, 0, size - 1, &cont[1]);
            printf("\nAreglo ordenado: ");
            printArray(lista, size);
        }
        else
        {
            printf("\nAreglo original: ");
            printArray(lista, size);
            mergeSortE4(lista, 0, size - 1, &cont[2]);
            printf("\nAreglo ordenado: ");
            printArray(lista, size);
        }
        if (i % 5 == 0)
            ordenamiento++;
    }
    for (int i = 0; i < 3; i++)
        cont[i].suma = cont[i].comparaciones + cont[i].intercambios + cont[i].inserciones;
    imprimirResultados(size, cont);

    return 0;
}