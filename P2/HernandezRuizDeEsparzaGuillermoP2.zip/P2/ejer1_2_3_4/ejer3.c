#include "ordenamientos.h"

int main()
{
    srand(time(NULL));
    int size=20, lista[size], repetir, seleccionMenu;
    do
    {
        do
        {
            system("clear");
            printf("---Menu de llenado---\n");
            printf(">Para ingresar manuelmente los datos, ingrese 1\n>Para generar los datos aleatoriamente, ingrese 2\n>>Seleccion: ");
            scanf("%d", &seleccionMenu);
        } while (seleccionMenu != 1 && seleccionMenu != 2);
        if (seleccionMenu == 1)
            leerLista(lista, size);
        else
            listaAleatoria(lista, size);
        do
        {
            system("clear");
            printf("---Menu de ordenamiento---\n");
            printf(">Para ordenar utlizando insertonSort ingrese 1\n>Para ordenar utilizando selectionSort ingrese 2\n>Para ordenar utilizando bubbleSort ingrese 3\n>Para ordenar utilizando heapSort ingrese 4\n>Para ordenar utilizando quickSort ingrese 5\n>Para ordenar utilizando mergeSort ingrese 6\n>>Seleccion: ");
            scanf("%d", &seleccionMenu);
        } while (seleccionMenu <1 || seleccionMenu >6);
        system("clear");
        if (seleccionMenu == 1)
            insertionSort(lista, size);
        else if (seleccionMenu == 2)
            selectionSort(lista, size);
        else if (seleccionMenu == 3)
            bubbleSort(lista, size);
        else if (seleccionMenu == 4){
            printf("\nAreglo original: ");
	        printArray(lista, size);
            heapSort(lista, size);
            printf("\nAreglo ordenado: ");
	        printArray(lista, size);
        }
        else if (seleccionMenu == 5){
            printf("\nAreglo original: ");
            printArray(lista, size);
            quickSort(lista, 0,size-1);
            printf("\nAreglo ordenado: ");
            printArray(lista, size);
        }
        else if (seleccionMenu == 6){
            printf("\nAreglo original: ");
            printArray(lista, size);
            mergeSort(lista, 0, size-1);
            printf("\nAreglo ordenado: ");
            printArray(lista, size);
        }
        printf("\n\n\nDesea repetir el programa?\n>Si ingrese 1\n>No ingrese cualquier otro numero\n>>Seleccion: ");
        scanf("%d", &repetir);
    } while (repetir==1);
    return 0;
}