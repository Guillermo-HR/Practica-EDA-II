#include "ordenamientos.h"

void countingSort(int arr[], int size)
{
    int countingArray[10], arregloOrdenado[size];
    int letras[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    readCounting(arr, size);
    for (int i = 0; i < size; i++)
        arregloOrdenado[i] = -2;
    for (int i = 0; i < 10; i++)
        countingArray[i] = 0;
    for (int i = 0; i < size; i++)
        countingArray[arr[i]]++;
    printf("Arreglo contador: \n");
    printCharArray(letras, 10);
    printArray(countingArray, 10);
    for (int i = 1; i < 10; i++)
        countingArray[i] += countingArray[i - 1];
    printf("Arreglo contador suma acumulada: \n");
    printCharArray(letras, 10);
    printArray(countingArray, 10);
    printf("ORDENANDO...\n");
    for (int i = size - 1; i >= 0; i--)
    {
        arregloOrdenado[countingArray[arr[i]] - 1] = arr[i];
        countingArray[arr[i]]--;
        printf("\nArreglo contador: \n");
        printCharArray(letras, 10);
        printArray(countingArray, 10);
        printf("Arreglo ordenado: \n");
        printCharArray(arregloOrdenado, size);
    }
}

void readCounting(int arr[], int size)
{
    int i;
    char temp;
    for (i = 0; i < size; i++)
    {
        printf("Ingrese un caracter entre a y j\n>> ");
        fflush(stdin);
        scanf("%c", &temp);
        arr[i] = (int)temp - 97;
    }
}

void radixSort(char *arr[], int size)
{
    Cola *cola[4];
    numero *temporal;
    for (int i = 0; i < 4; i++)
        cola[i] = crearCola();
    for (int i = 0; i < size; i++)
    {
        arr[i] = (char *)malloc(4 * sizeof(char));
        printf("Ingrese un entero de 4 digitos usando numeros entre 1 y 4\n>> ");
        fflush(stdin);
        scanf("%s", arr[i]);
    }
    for (int i = 3; i >= 0; i--)
    {
        for (int j = 0; j < size; j++)
            insertar(cola[arr[j][i] - 49], arr[j]);
        printf("\nOrdenando por: ");
        switch (i)
        {
        case 0:
            printf("Unidades de millar\n");
            break;
        case 1:
            printf("Centenas\n");
            break;
        case 2:
            printf("Decenas\n");
            break;
        case 3:
            printf("Unidades\n");
            break;
        }
        printf("Lista 1: ");
        listar(*cola[0]);
        printf("Lista 2: ");
        listar(*cola[1]);
        printf("Lista 3: ");
        listar(*cola[2]);
        printf("Lista 4: ");
        listar(*cola[3]);
        for (int j = 0; j < size; j++)
        {
            temporal = borrar(cola[0]);
            if (temporal == NULL)
                temporal = borrar(cola[1]);
            if (temporal == NULL)
                temporal = borrar(cola[2]);
            if (temporal == NULL)
                temporal = borrar(cola[3]);
            strcpy(arr[j], temporal->dato);
            free(temporal);
        }
        printf("\nLista ordenada\n");
        for (int i = 0; i < size; i++)
            printf("%s ", arr[i]);
        printf("\n");
    }
}
