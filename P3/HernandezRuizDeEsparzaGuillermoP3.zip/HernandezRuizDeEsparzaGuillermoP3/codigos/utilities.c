#include "utilities.h"

void printCharArray(int arr[], int size)
{
    for (int i = 0; i < size; i++)
        printf("%c ", arr[i]+97);
    printf("\n");
}

void printArray(int arr[], int size)
{
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

