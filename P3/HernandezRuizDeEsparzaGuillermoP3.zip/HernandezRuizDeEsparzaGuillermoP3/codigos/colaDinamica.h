#ifndef COLADINAMICA_H_INCLUDED
#define COLADINAMICA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nodo
{
    char info[5];
    struct nodo *sig; // APUNTADOR AL SIG NODO DE LA COLA
} Nodo;

typedef struct
{
    Nodo *h, *t;
} Cola;

typedef struct
{
    char dato[5];
} numero;

// FUNCIONES
void insertar(Cola *cola, char dato[5]);
numero *borrar(Cola *cola);
// FUNCIONES AUXILIARES
Cola *crearCola();
int colaVacia(Cola cola);
void inicializarCola(Cola *cola);
void listar(Cola cola);

#endif // COLADINAMICA_H_INCLUDED
