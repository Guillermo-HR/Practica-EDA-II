#include "colaDinamica.h"

Cola *crearCola()
{
    Cola *nuevaCola;
    nuevaCola = (Cola *)malloc(sizeof(Cola));
    if (nuevaCola == NULL)
    {
        printf("Error: Espacio insuficiente...");
        exit(0);
    }
    // INICIALIZANDO h y t
    nuevaCola->h = NULL;
    nuevaCola->t = NULL;
    return nuevaCola;
}

void insertar(Cola *cola, char dato[5])
{
    Nodo *nuevoNodo;
    // CREA EL NODO
    nuevoNodo = (Nodo *)malloc(sizeof(Nodo));
    if (nuevoNodo == NULL)
    {
        printf("Error: memoria insuficiente...");
        exit(0);
    }
    // 1.ASIGNA VALORES AL NODO
    strcpy(nuevoNodo->info, dato);
    nuevoNodo->sig = NULL;
    // 2.INSERTA EL NODO EN LA COLA
    if (colaVacia(*cola))
        cola->h = cola->t = nuevoNodo;
    else
    {
        cola->t->sig = nuevoNodo;
        cola->t = nuevoNodo;
    }
}

void listar(Cola cola)
{
    Nodo *q;
    // printf("\n");
    if (colaVacia(cola))
        printf("No hay datos en la cola");
    else
    {
        for (q = cola.h; q != NULL; q = q->sig)
            printf("%s ", q->info);
    }
    printf("\n");
}

int colaVacia(Cola cola)
{
    return cola.h == NULL;
}

numero *borrar(Cola *cola)
{
    numero *dato;
    Nodo *q = cola->h;
    // BORRA EL DATO
    if (!colaVacia(*cola))
    {
        if (cola->h == cola->t)
            cola->h = cola->t = NULL;
        else
            cola->h = cola->h->sig;
        dato = (numero *)malloc(sizeof(numero));
        strcpy(dato->dato, q->info);
        free(q); // LIBERA LA MEMORIA
        return dato;
    }
    else
        return NULL;
}

void inicializarCola(Cola *cola)
{
    Nodo *q = cola->h;
    if (!colaVacia(*cola))
    {
        // LIBERA MEMORIA
        while (q != NULL)
        {
            cola->h = cola->h->sig;
            free(q); // LIBERA LA MEMORIA
            q = cola->h;
        }
        // INICIALIZA APUNTADORES COLA
        cola->h = cola->t = NULL;
    }
}
