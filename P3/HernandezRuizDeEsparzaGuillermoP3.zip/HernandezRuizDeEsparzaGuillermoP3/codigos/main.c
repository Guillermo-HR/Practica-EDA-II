#include "ordenamientos.h"

int main()
{
    int size=20, arr[size];
    char *arrChar[size];
    int repetir, menu;
    do
    {
        system("clear");
        do
        {
            printf("Para ordenar usand counting sort ingrese 1\nPara ordenar usando radix sort ingrese 2\n>> ");
            scanf("%d", &menu);
        } while (menu < 1 || menu > 2);
        if(menu==1)
            countingSort(arr, size);
        else
            radixSort(arrChar, size);
        printf("\nPara repetir ingrese 1, para salir cualquier otro numero\n>> ");
        scanf("%d", &repetir);
    }while (repetir == 1);
    
    return 0;
}