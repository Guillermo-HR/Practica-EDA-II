#ifndef ORDENAMIENTOS_H
#define ORDENAMIENTOS_H

#include "utilities.h"
#include "colaDinamica.h"

void countingSort(int arr[], int size);
void readCounting(int arr[], int size);
void radixSort(char *arr[], int size);

#endif