#ifndef UTILITIES_H
#define UTILITIES_H

#include <stdio.h>
#include <stdlib.h>

void printCharArray(int arr[], int size);
void printArray(int arr[], int size);
#endif