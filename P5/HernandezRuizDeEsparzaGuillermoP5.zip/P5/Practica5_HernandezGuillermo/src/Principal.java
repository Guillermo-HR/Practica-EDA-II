import java.util.Scanner;
import java.util.HashMap;

public class Principal {
    public static void main(String[] args) throws Exception {
        int menu, menuInterno, valor;
        do {
            menu = menu();
            switch (menu) {
                case 1:
                    metodos();
                    break;
                case 2:
                    HashModulo hashMod = new HashModulo();
                    do {
                        menuInterno = menuPlegamiento();
                        switch (menuInterno) {
                            case 1:
                                System.out.println("Ingrese el valor a insertar");
                                Scanner sc = new Scanner(System.in);
                                valor = sc.nextInt();
                                hashMod.insertarHash(valor);
                                break;
                            case 2:
                                hashMod.imprimir();
                                break;
                            case 3:
                                System.out.println("Ingrese el valor a buscar");
                                Scanner sc2 = new Scanner(System.in);
                                int valor2 = sc2.nextInt();
                                hashMod.buscar(valor2);
                                break;
                            case 4:
                                System.out.println("Saliendo...");
                                break;
                            default:
                                System.out.println("Opcion no valida");
                                break;
                        }
                    } while (menuInterno != 4);
                    break;
                case 3:
                    Encadenamiento encadenamiento = new Encadenamiento();
                    do {
                        menuInterno = menuEncadenamiento();
                        switch (menuInterno) {
                            case 1:
                                System.out.println("Ingrese el valor a insertar");
                                Scanner sc = new Scanner(System.in);
                                valor = sc.nextInt();
                                encadenamiento.insertarEncad(valor);
                                break;
                            case 2:
                                System.out.println("Saliendo...");
                                break;
                            default:
                                System.out.println("Opcion no valida");
                                break;
                        }
                    } while (menuInterno != 2);
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        } while (menu != 4);
    }

    private static int menu() {
        int opcion;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Menu");
            System.out.println("1.- Manejo de tablas hash en java");
            System.out.println("2.- Funcion hash por modulo");
            System.out.println("3.- Encadenamiento");
            System.out.println("4.- Salir");
            System.out.print("Ingrese una opcion: ");
            try {
                opcion = sc.nextInt();
            } catch (Exception e) {
                System.out.println("Valor no valido\n");
                opcion = 0;
            }
        } while (opcion < 1 || opcion > 4);
        return opcion;
    }

    private static int menuPlegamiento() {
        int opcion;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Menu");
            System.out.println("1.- Agregar elementos");
            System.out.println("2.- Implimir lista");
            System.out.println("3.- Buscar elementos");
            System.out.println("4.- Salir");
            System.out.print("Ingrese una opcion: ");
            try {
                opcion = sc.nextInt();
            } catch (Exception e) {
                System.out.println("Valor no valido\n");
                opcion = 0;
            }
        } while (opcion < 1 || opcion > 4);
        return opcion;
    }

    private static int menuEncadenamiento() {
        int opcion;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Menu");
            System.out.println("1.- Agregar elementos");
            System.out.println("2.- Salir");
            System.out.print("Ingrese una opcion: ");
            try {
                opcion = sc.nextInt();
            } catch (Exception e) {
                System.out.println("Valor no valido\n");
                opcion = 0;
            }
        } while (opcion < 1 || opcion > 2);
        return opcion;
    }

    private static HashMap<Integer, String> llenarHashMap() {
        HashMap<Integer, String> alumnos = new HashMap<>();
        alumnos.put(319220553, "Guillermo Hernandez Ruiz");
        alumnos.put(631985247, "Juan Perez Lopez");
        alumnos.put(123456789, "Maria Morales Martinez");
        alumnos.put(987654321, "Jose Luis Garcia");
        alumnos.put(123456789, "Maria Perez Martinez");
        alumnos.put(359485123, "Juan Hernandez Ruiz");
        alumnos.put(123456789, "Maria Hernandez Martinez");
        return alumnos;
    }

    private static void metodos() {
        HashMap<Integer, String> alumnos = llenarHashMap();
        System.out.println("Prueba de metodos");
        System.out.println("Alumnos:");
        System.out.println("Tamaño: " + alumnos.size());
        System.out.println("Contiene la llave 123456789: " + alumnos.containsKey(123456789));
        System.out.println("Contiene la llave 153456680: " + alumnos.containsKey(153456680));
        System.out.println(
                "Contiene el valor Maria Hernandez Martinez: " + alumnos.containsValue("Maria Hernandez Martinez"));
        System.out.println(
                "Contiene el valor Maria Martinez Hernandez: " + alumnos.containsValue("Maria Martinez Hernandez"));
        System.out.println("Obtener el valor de la llave 123456789: " + alumnos.get(123456789));
        System.out.println("Obtener el valor de la llave 153456680: " + alumnos.get(153456680));
        System.out.println("Eliminar el valor de la llave 123456789: " + alumnos.remove(123456789));
        HashMap<Integer, String> alumnos2 = llenarHashMap();
        System.out.println("Alumnos es igual a alumnos2: " + alumnos.equals(alumnos2));
        System.out.println("Alumnos:");
        System.out.println("Tamaño: " + alumnos2.size());
        System.out.println("Eliminar todos los elementos");
        alumnos2.clear();
        System.out.println("Tamaño: " + alumnos2.size());
    }

}
