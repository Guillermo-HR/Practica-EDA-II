import java.util.LinkedList;

public class Encadenamiento {
    LinkedList<LinkedList<Integer>> lista = new LinkedList<>();
    private int tamaño = 15;

    public Encadenamiento() {
        for (int i = 0; i < tamaño; i++)
            lista.add(new LinkedList<Integer>());
    }

    public void insertarEncad(int valor) {
        int posicion = (int) (Math.random() * 14 + 1);
        lista.get(posicion).add(valor);
        System.out.println("El valor " + valor + " se agrego en la lista " + posicion);
        System.out.println("Lista:");
        imprimir();
    }

    public void imprimir() {
        for (int i = 0; i < tamaño; i++) {
            System.out.print(i + " -> ");
            for (int j = 0; j < lista.get(i).size(); j++) {
                System.out.print(lista.get(i).get(j) + " -> ");
            }
            System.out.println("\\");
            System.out.println();
        }
    }

}
