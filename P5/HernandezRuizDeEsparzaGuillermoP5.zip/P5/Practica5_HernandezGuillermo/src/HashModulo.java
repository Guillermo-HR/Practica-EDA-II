import java.util.LinkedList;

public class HashModulo {
    private int tamaño = 15;
    LinkedList<Integer> tabla = new LinkedList<Integer>();

    public HashModulo() {
        for (int i = 0; i < tamaño; i++)
            tabla.add(-1);
    }

    public void insertarHash(int valor) {
        int posicion = funcionHash(valor, -1);
        if (posicion == -1) {
            System.out.println("No se pudo guardar el valor");
        } else {
            tabla.set(posicion, valor);
            System.out.println("El valor " + valor + " se encuentra en la posicion " + posicion);
        }
    }

    public void buscar(int valor) {
        int posicion = funcionHash(valor, valor);
        if (posicion == -1) {
            System.out.println("El valor no se encuentra en la tabla");
            return;
        }
        System.out.println("El valor " + valor + " se encuentra en la posicion " + posicion);
    }

    public void imprimir() {
        System.out.println("Tabla hash:");
        System.out.println("Posicion\tValor");
        for (int i = 0; i < tamaño; i++) {
            if (tabla.get(i) != -1)
                System.out.println(i + "\t\t" + tabla.get(i));
            else
                System.out.println(i + "\t\t" + null);
        }
        System.out.println();
    }

    private int funcionHash(int valor, int condicion) {
        int digitos = (int) (Math.log10(valor) + 1);
        int suma = 0;
        if (digitos != 9)
            return -1;

        LinkedList<Integer> pliegues = new LinkedList<Integer>();
        pliegues.add(valor / 100000);
        pliegues.add((valor % 100000) / 10);
        pliegues.add(valor % 10);
        for (int i = 0; i < pliegues.size(); i++)
            suma += pliegues.get(i);

        // modulo 15
        int posicion = suma % 15;
        for (int i = posicion; i < tabla.size(); i++) {
            if (tabla.get(i) == condicion)
                return i;
        }
        for (int i = posicion - 1; i > 0; i--) {
            if (tabla.get(i) == condicion)
                return i;
        }

        return -1;
    }
}