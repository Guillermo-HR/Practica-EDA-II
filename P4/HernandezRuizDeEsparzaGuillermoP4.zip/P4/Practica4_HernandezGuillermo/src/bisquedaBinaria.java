import java.util.List;

public class bisquedaBinaria {
    public static boolean BB_T_F(List<Integer> lista, int numero) {
        quickSort.QuickSort(lista, 0, lista.size() - 1);
        boolean encontrado = false;
        int inicio = 0;
        int fin = lista.size() - 1;
        int mitad;
        while (inicio <= fin) {
            mitad = (inicio + fin) / 2;
            if (lista.get(mitad) == numero) {
                encontrado = true;
                break;
            } else if (lista.get(mitad) < numero) {
                inicio = mitad + 1;
            } else {
                fin = mitad - 1;
            }
        }
        System.out.println("El "+numero+" esta en la lista: "+encontrado);
        return encontrado;
    }
    public static int BB_Rep(List<Integer> lista, int numero) {
        quickSort.QuickSort(lista, 0, lista.size() - 1);
        int conteo = 0;
        int inicio = 0;
        int fin = lista.size() - 1;
        int mitad;
        int index;
        while (inicio <= fin) {
            mitad = (inicio + fin) / 2;
            if (lista.get(mitad) == numero) {
                index = mitad;
                while (index < lista.size() && lista.get(index) == numero){
                    index++;
                    conteo++;
                }
                index = mitad-1;
                while (index >= 0 && lista.get(index) == numero){
                    index--;
                    conteo++;
                }
                break;
            } else if (lista.get(mitad) < numero) {
                inicio = mitad + 1;
            } else {
                fin = mitad - 1;
            }
        }
        System.out.println("El "+numero+" se repite "+conteo+" veces");
        return conteo;
    }
}
