import java.util.List;
public class quickSort {
    static int partition(List<Integer> lista, int low, int high) {
        int pivot = lista.get(high);
        int swap;
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (lista.get(j) <= pivot) {
                i++;
                swap = lista.get(i);
                lista.set(i, lista.get(j));
                lista.set(j, swap);
            }
        }
        int temp = lista.get(i + 1);
        lista.set(i + 1, lista.get(high));
        lista.set(high, temp);
        return i + 1;
    }
    static void QuickSort(List<Integer> lista, int low, int high) {
        if (low < high) {
            int pi = partition(lista, low, high);
            QuickSort(lista, low, pi - 1);
            QuickSort(lista, pi + 1, high);
        }
    }
}
