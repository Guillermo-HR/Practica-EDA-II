import java.util.LinkedList;
import java.util.List;
public class busquedaLineal {
    public static boolean BL_T_F(List<Integer> lista, int numero) {
        System.out.println("El "+numero+" esta en la lista: "+lista.contains(numero));
        return lista.contains(numero);
    }
    public static int BL_Index(List<Integer> lista, int numero) {
        int index = lista.indexOf(numero);
        if (index == -1)
            System.out.println("El "+numero+" no esta en la lista");
        else
            System.out.println("El "+numero+" esta en la lista en el indice: "+index);
        return index;
    }
    public static int BL_Rep(List<Integer> lista, int numero) {
        int conteo = 0;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i) == numero)
                conteo++;
        }
        System.out.println("El "+numero+" se repite "+conteo+" veces");
        return conteo;
    }
    public static List<automovil> BL_Marca(List<automovil> lista, String marca) {
        List<automovil> listaMarca = new LinkedList<>();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getMarca().equals(marca))
                listaMarca.add(lista.get(i));
        }
        return listaMarca;
    }
    public static List<automovil> BL_valor(List<automovil> lista, double valor) {
        List<automovil> listaValor = new LinkedList<>();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getValor()==valor)
            listaValor.add(lista.get(i));
        }
        return listaValor;
    }
}
