import java.util.LinkedList;
import java.util.List;
public class automovil {
    // Atributos
    String marca;
    String color;
    List<String> daños = new LinkedList<>();
    int año;
    int km;
    double valor;
    // Constructores
    public automovil(String marca, String color, int año, double valor, int km){
        this.marca = marca;
        this.color = color;
        this.año = año;
        this.valor = valor;
        this.km = km;
        this.daños.add("Ninguno");
    }
    public automovil(String marca, String color, List<String> defectos, int año, double valor, int km){
        this.marca = marca;
        this.color = color;
        this.año = año;
        this.valor = valor;
        this.km = km;
        this.daños = defectos;
    }
    // Metodos
    public void añadirDefecto(String defecto){
        if (this.daños.get(0) == "Ninguno")
            this.daños.remove(0);
        if (!this.daños.contains(defecto)){
            this.daños.add(defecto);
        }
        System.out.println("");
    }
    public void fichaTecnica(){
        System.out.println("------------------------");
        System.out.println("Marca: "+this.marca);
        System.out.println("Color: "+this.color);
        System.out.println("Año: "+this.año);
        System.out.println("Valor: $"+this.valor);
        System.out.println("Kilometraje: "+this.km);
        System.out.println("Daños: "+this.daños);
    }
    public void manejar(int km){
        this.km += km;
    }
    public String getMarca(){
        return this.marca;
    }
    public double getValor(){
        return this.valor;
    }
}
