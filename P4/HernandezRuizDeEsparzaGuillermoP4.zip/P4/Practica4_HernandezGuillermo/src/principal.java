import java.util.LinkedList;
import java.util.List;

public class principal {
        public static void main(String[] args) {
                /*
                 * List<Integer> lista1 = new LinkedList<>();
                 * imprimirLista(lista1);
                 * System.out.println("***");
                 * // Agregar elementos a la lista
                 * lista1.add(15);
                 * lista1.add(30);
                 * lista1.add(6);
                 * lista1.add(90);
                 * lista1.add(90);
                 * lista1.add(32);
                 * lista1.add(76);
                 * lista1.add(80);
                 * System.out.println("Estado 1 ");
                 * imprimirLista(lista1);
                 * System.out.println("***");
                 * // Insertat elementos de la lista en indices especificos
                 * lista1.add(3, 300);
                 * lista1.add(4, 500);
                 * lista1.add(5, 700);
                 * System.out.println(" Estado 2 ");
                 * imprimirLista(lista1);
                 * System.out.println(" *** ");
                 * // Intercambiar elementos de la lista en indices especificos
                 * lista1.set(1, 14);
                 * lista1.set(2, 16);
                 * lista1.set(3, 18);
                 * System.out.println(" Estado 3 ");
                 * imprimirLista(lista1);
                 * System.out.println(" *** ");
                 * // Crear sublistas
                 * List<Integer> lista2, lista3;
                 * lista2 = lista1.subList(2, 4);
                 * lista3 = lista1.subList(2, 6);
                 * imprimirLista(lista2);
                 * System.out.println(" *** ");
                 * imprimirLista(lista3);
                 * System.out.println(" *** ");
                 * // Comparar 2 listas
                 * System.out.println(lista2.equals(lista3));
                 * System.out.println(" *** ");
                 * // Eliminar elementos de la lista
                 * lista1.remove(2);
                 * imprimirLista(lista1);
                 * System.out.println(" *** ");
                 * System.out.println(lista1.isEmpty());
                 * System.out.println(" *** ");
                 * //Buscar elementos en la lista
                 * System.out.println("El 90 esta en la lista: "+lista1.contains(90));
                 * System.out.println("El 100 esta en la lista: "+lista1.contains(100));
                 * System.out.println("Indice del 90 en la lista: "+lista1.indexOf(90));
                 * System.out.println("Indice del 100 en la lista: "+lista1.indexOf(100));
                 * System.out.println(" *** ");
                 * // Busqueda lineal
                 * System.out.println("Lista para busqueda lineal: ");
                 * imprimirLista(lista1);
                 * System.out.println("Busqueda lineal");
                 * busquedaLineal.BL_T_F(lista1, 90);
                 * busquedaLineal.BL_Index(lista1, 100);
                 * busquedaLineal.BL_Rep(lista1, 90);
                 * System.out.println("\nLista para busqueda binaria: ");
                 * imprimirLista(lista1);
                 * System.out.println("Busqueda binaria");
                 * bisquedaBinaria.BB_T_F(lista1, 90);
                 * bisquedaBinaria.BB_T_F(lista1, 88);
                 * bisquedaBinaria.BB_Rep(lista1, 100);
                 * bisquedaBinaria.BB_Rep(lista1, 90);
                 */
                List<String> defectos = new LinkedList<>();
                defectos.add("Clutch defectuoso");
                defectos.add("Balatas desgastados");
                defectos.add("Falta de aceite");
                defectos.add("Llanta ponchada");
                defectos.add("Luces rotas");
                defectos.add("Sistema de inyeccion defectuoso");
                defectos.add("Rotula desgastada");

                automovil auto1 = new automovil("Audi", "Blanco", defectos.subList(0, 3), 2020, 100000, 0);
                auto1.manejar(500);
                automovil auto2 = new automovil("BMW", "Rojo", 2000, 50000, 10000);
                auto2.manejar(1000);
                auto2.añadirDefecto(defectos.get(5));
                auto2.añadirDefecto(defectos.get(6));
                automovil auto3 = new automovil("VW", "negro", defectos.subList(2, 5), 2015, 70000, 30000);
                auto3.manejar(3070);
                automovil auto4 = new automovil("Lexus", "Plata", defectos.subList(3, 6), 2017, 130000, 47681);
                automovil auto5 = new automovil("Mazda", "Azul", defectos.subList(4, 7), 2019, 150000, 0);
                auto5.manejar(20000);
                automovil auto6 = new automovil("Nissan", "Verde", 2018, 120000, 70000);
                automovil auto7 = new automovil("Toyota", "Gris", 2022, 50000, 0);
                automovil auto8 = new automovil("Ferrari", "Rojo", 1962, 48000000, 0);
                automovil auto9 = new automovil("Audi", "Azul", 2010, 130000, 0);
                automovil auto10 = new automovil("Lexus", "Plata", defectos.subList(0, 2), 2019, 180000, 7691);
                List<automovil> listaAutos = new LinkedList<>();
                listaAutos.add(auto1);
                listaAutos.add(auto2);
                listaAutos.add(auto3);
                listaAutos.add(auto4);
                listaAutos.add(auto5);
                listaAutos.add(auto6);
                listaAutos.add(auto7);
                listaAutos.add(auto8);
                listaAutos.add(auto9);
                listaAutos.add(auto10);
                System.out.println("Lista de autos: ");
                imprimirListaAutos(listaAutos);
                System.out.println("***\nBusuqeda lineal");
                List<automovil> listaBusqueda = new LinkedList<>();
                listaBusqueda = busquedaLineal.BL_Marca(listaAutos, "Audi");
                System.out.println("Lista de autos con marca Audi: ");
                imprimirListaAutos(listaBusqueda);
                listaBusqueda = busquedaLineal.BL_Marca(listaAutos, "Toyota");
                System.out.println("Lista de autos con marca Toyota: ");
                imprimirListaAutos(listaBusqueda);
                listaBusqueda = busquedaLineal.BL_Marca(listaAutos, "Ford");
                System.out.println("Lista de autos con marca Ford: ");
                imprimirListaAutos(listaBusqueda);
                listaBusqueda = busquedaLineal.BL_valor(listaAutos, 100000);
                System.out.println("Lista de autos con valor de 100000: ");
                imprimirListaAutos(listaBusqueda);
                listaBusqueda = busquedaLineal.BL_valor(listaAutos, 48000000);
                System.out.println("Lista de autos con valor de 48000000: ");
                imprimirListaAutos(listaBusqueda);
                listaBusqueda = busquedaLineal.BL_valor(listaAutos, 1000);
                System.out.println("Lista de autos con valor de 1000: ");
                imprimirListaAutos(listaBusqueda);
        }

        public static void imprimirLista(List<Integer> listaPrint) {
                for (Integer var : listaPrint)
                        System.out.println(var);
        }

        public static void imprimirListaAutos(List<automovil> listaPrint) {
                System.out.println("");
                for (automovil auto : listaPrint)
                        auto.fichaTecnica();
                System.out.println("");
        }
}