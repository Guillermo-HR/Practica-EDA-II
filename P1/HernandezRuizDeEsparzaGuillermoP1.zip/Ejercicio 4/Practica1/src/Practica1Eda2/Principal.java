package Practica1Eda2;

public class Principal {
    
    public static void main(String args[]){  
        int[] arr1 = {369,699,506,709,883,468,612,827,873,589,229,821,763,450,210,302,842,915,132,750}; //llena el arreglo con unos 20 valores
        int[] arr2 = {569,784,263,967,130,449,400,641,583,574,155,838,618,141,497,19,547,287,673,154}; //llena el arreglo con unos 20 valores

        System.out.println("Arreglos Originales");  
        Utilerias.imprimirArreglo(arr1);
        Utilerias.imprimirArreglo(arr2);
        
        Insercion.insertionSort(arr1);
        
        Seleccion seleccion = new Seleccion();   
        seleccion.selectionSort(arr2);  
       
             
        System.out.println("Arreglos ordenados");  
        Utilerias.imprimirArreglo(arr1);
        Utilerias.imprimirArreglo(arr2);
        
    }  
    
   
}
