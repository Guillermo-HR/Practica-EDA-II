# include "ordenamientos.h"

int main(){
    int lista[]={-9,20,6,33,17,0,3,3,-10,100}, n=10;
    
    //selectionSort(lista, n);
    //insertionSort(lista, n);
    bubbleSort(lista, n);
    return 0;
}