#ifndef ORDENAMIENTOS_H_
#define ORDENAMIENTOS_H_

#include "utilidades.h"

void selectionSort(int arreglo[], int n);
void insertionSort(int a[], int n);
/*Ejercicio 1*/
void bubbleSort(int a[], int size);
/*Ejercicio 3*/
void selectionSortE3(int arreglo[], int n, Contador *cont);
void insertionSortE3(int a[], int n, Contador *cont);
void bubbleSortE3(int a[], int size, Contador *cont);

#endif