#include "ordenamientos.h"

void selectionSort(int arreglo[], int n)
{
	int indiceMenor, i, j;
	printf("\nSelection Sort\n");
	printf("arreglo original: ");
	printArray(arreglo, n);
	for (i = 0; i < n - 1; i++)
	{
		indiceMenor = i;
		for (j = i + 1; j < n; j++)
		{
			if (arreglo[j] < arreglo[indiceMenor])
				indiceMenor = j;
		}
		if (i != indiceMenor)
			swap(&arreglo[i], &arreglo[indiceMenor]);
		printf("\nIteracion numero %d \n", i + 1);
		printArray(arreglo, n);
	}
}

void insertionSort(int a[], int n)
{
	int i, j;
	int aux;
	printf("\nInsertion Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = 1; i < n; i++)
	{
		j = i;
		aux = a[i];
		while (j > 0 && aux < a[j - 1])
		{
			a[j] = a[j - 1];
			j--;
		}
		a[j] = aux;

		printf("\nIteracion numero %d \n", i);
		printArray(a, n);
	}
}

/*Ejercicio 1*/
void bubbleSort(int a[], int size)
{
	int i, j, n, iteraciones = 1;
	int bandera;
	n = size;
	printf("\nBubble Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = n - 1; i > 0; i--)
	{
		bandera = 1;
		for (j = 0; j < i; j++)
		{
			if (a[j] > a[j + 1])
			{
				swap(&a[j], &a[j + 1]);
				bandera = 0;
			}
		}
		if (bandera)
		{
			printf("\nEl arreglo ya esta ordenado\t se termino en %i iteraciones\n", iteraciones);
			printArray(a, n);
			return;
		}
		printf("\nIteracion numero %d \n", iteraciones);
		iteraciones++;
		printArray(a, n);
	}
	iteraciones--;
}

/*Ejercicio 3*/
void selectionSortE3(int arreglo[], int n, Contador *cont)
{
	int indiceMenor, i, j;
	printf("\n\nSelection Sort\n");
	printf("arreglo original: ");
	printArray(arreglo, n);
	for (i = 0; i < n - 1; i++)
	{
		indiceMenor = i;
		for (j = i + 1; j < n; j++)
		{
			cont->comparaciones++;
			if (arreglo[j] < arreglo[indiceMenor])
				indiceMenor = j;
		}
		cont->comparaciones++;
		if (i != indiceMenor)
		{
			swap(&arreglo[i], &arreglo[indiceMenor]);
			cont->intercambios++;
		}

		printf("\nIteracion numero %d \n", i + 1);
		printArray(arreglo, n);
	}
}

void insertionSortE3(int a[], int n, Contador *cont)
{
	int i, j;
	int aux;
	printf("\n\nInsertion Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = 1; i < n; i++)
	{
		j = i;
		aux = a[i];
		if (aux > a[j - 1])
			cont->comparaciones += 3;
		while (j > 0 && aux < a[j - 1])
		{
			cont->comparaciones += 3;
			a[j] = a[j - 1];
			j--;
		}
		if (j==0)
			cont->comparaciones++;
		else if (j!=i)
			cont->comparaciones += 3;
		cont->inserciones++;
		a[j] = aux;

		printf("\nIteracion numero %d \n", i);
		printArray(a, n);
	}
}

void bubbleSortE3(int a[], int size, Contador *cont)
{
	int i, j, n, iteraciones = 1;
	int bandera;
	n = size;
	printf("\nBubble Sort\n");
	printf("arreglo original: ");
	printArray(a, n);
	for (i = n - 1; i > 0; i--)
	{
		bandera = 1;
		for (j = 0; j < i; j++)
		{
			cont->comparaciones++;
			if (a[j] > a[j + 1])
			{
				cont->intercambios++;
				swap(&a[j], &a[j + 1]);
				bandera = 0;
			}
		}
		if (bandera)
		{
			printf("\nEl arreglo ya esta ordenado\t se termino en %i iteraciones\n", iteraciones);
			printArray(a, n);
			return;
		}
		printf("\nIteracion numero %d \n", iteraciones);
		iteraciones++;
		printArray(a, n);
	}
}