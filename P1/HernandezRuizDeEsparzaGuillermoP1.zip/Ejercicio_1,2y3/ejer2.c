#include "ordenamientos.h"

int main()
{
    srand(time(NULL));
    int lista[20], repetir, seleccionMenu;
    do
    {
        do
        {
            system("clear");
            printf("---Menu de llenado---\n");
            printf(">Para ingresar manuelmente los datos, ingrese 1\n>Para generar los datos aleatoriamente, ingrese 2\n>>Seleccion: ");
            scanf("%d", &seleccionMenu);
        } while (seleccionMenu != 1 && seleccionMenu != 2);
        if (seleccionMenu == 1)
            leerLista(lista, 20);
        else
            listaAleatoria(lista, 20);
        do
        {
            system("clear");
            printf("---Menu de ordenamiento---\n");
            printf(">Para ordenar utlizando insertonSort ingrese 1\n>Para ordenar utilizando selectionSort ingrese 2\n\
            >Para ordenar utilizando bubbleSort ingrese 3\n>>Seleccion: ");
            scanf("%d", &seleccionMenu);
        } while (seleccionMenu <1 || seleccionMenu >3);
        system("clear");
        if (seleccionMenu == 1)
            insertionSort(lista, 20);
        else if (seleccionMenu == 2)
            selectionSort(lista, 20);
        else
            bubbleSort(lista, 20);
        printf("\n\n\nDesea repetir el programa?\n>Si ingrese 1\n>No ingrese cualquier otro numero\n>>Seleccion:");
        scanf("%d", &repetir);
    } while (repetir==1);
    return 0;
}