import java.util.LinkedList;

public class GraphPonderado {
    int V;
    LinkedList<Integer> adjMatrix[];

    GraphPonderado(int v) {
        V = v;
        adjMatrix = new LinkedList[v];
        for (int i = 0; i < v; i++) {
            adjMatrix[i] = new LinkedList<Integer>();
            for (int j = 0; j < v; j++)
                adjMatrix[i].add(0);
        }
    }

    void addEdge(int v, int w, int peso) {
        try {
            adjMatrix[v].set(w, peso);
        } catch (Exception e) {
            System.out.println("Nodos no validos");
        }
    }

    void printGraph() {
        System.out.println("Matriz de adyacecia");
        System.out.print("\t");
        for (int i = 0; i < V; i++)
            System.out.print(i + "\t");
        System.out.println();
        for (int v = 0; v < V; v++) {
            System.out.print(v + "\t");
            for (int j = 0; j < V; j++)
                System.out.print(adjMatrix[v].get(j) + "\t");
            System.out.println("\n");
        }
    }

    int primmUtil(int nodo, boolean visitados[], int suma, LinkedList<LinkedList<Integer>> list) {
        visitados[nodo] = true;
        boolean banderaWhile = true;
        for (int i = 0; i < V; i++) {
            if (adjMatrix[nodo].get(i) != 0) {
                LinkedList<Integer> temporal = new LinkedList<>();
                temporal.add(adjMatrix[nodo].get(i));
                temporal.add(nodo);
                temporal.add(i);
                if (list.isEmpty())
                    list.add(temporal);
                else if (temporal.get(0) >= list.get(list.size() - 1).get(0))
                    list.add(temporal);
                else
                    for (int j = 0; j < list.size(); j++)
                        if (temporal.get(0) < list.get(j).get(0)) {
                            list.add(j, temporal);
                            break;
                        }
            }
        }
        while (!list.isEmpty() && banderaWhile) {
            LinkedList<Integer> temporal = new LinkedList<>();
            temporal = list.removeFirst();
            if (!visitados[temporal.get(2)]) {
                suma += temporal.get(0);
                banderaWhile = false;
                System.out.print("(" + temporal.get(1) + "->" + temporal.get(2) + ") ");
                suma = primmUtil(temporal.get(2), visitados, suma, list);
            }
        }
        return suma;
    }

    void primm(int nodo) {
        LinkedList<LinkedList<Integer>> list = new LinkedList<>();
        boolean visitados[] = new boolean[V];
        int suma = 0;
        System.out.println("Recorrido del grafo Prim desde el nodo " + nodo);
        System.out.print("MST{ ");
        suma = primmUtil(nodo, visitados, suma, list);
        System.out.println("} = " + suma);
    }

}
