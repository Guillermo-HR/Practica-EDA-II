import java.util.Scanner;

public class Principal {
    public static void main(String[] args) throws Exception {
        /*
         * #Ejemplo practica
         * int V=5;
         * Graph graph =new Graph(V);
         * graph.addEdge(0, 1);
         * graph.addEdge(0, 4);
         * graph.addEdge(1, 2);
         * graph.addEdge(1, 3);
         * graph.addEdge(1, 4);
         * graph.addEdge(2, 3);
         * graph.addEdge(3, 4);
         * graph.addEdge(4, 4);
         * graph.printGraph(graph);
         */
        int menu, V;
        Graph graph;
        GraphPonderado graphPonderado;
        do {
            menu = menu();
            switch (menu) {
                case 1:
                    graph = crearGraph(1);
                    graph.printGraph(graph);
                    menuRecorrido(graph);
                    break;
                case 2:
                    graph = crearGraph(2);
                    graph.printGraph(graph);
                    menuRecorrido(graph);
                    break;
                case 3:
                    graphPonderado = crearGraphPonderado();
                    graphPonderado.printGraph();
                    menuRecorridoPonderado(graphPonderado);
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (menu != 4);

    }

    private static int menu() {
        int opcion = 0;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Menu:");
            System.out.println("1.- Crear grafo no dirigido");
            System.out.println("2.- Crear grafo dirigido");
            System.out.println("3.- Crear grafo dirigido ponderado");
            System.out.println("4.- Salir");
            System.out.print("opcion: ");
            opcion = sc.nextInt();
        } while (opcion < 1 || opcion > 4);

        return opcion;
    }

    private static void menuRecorrido(Graph graph) {
        int opcion = 0;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Menu:");
            System.out.println("1.- Recorrer el grafo con BFS");
            System.out.println("2.- Recorrer el grafo con DFS");
            System.out.println("3.- No recorrer grafo");
            System.out.print("opcion: ");
            opcion = sc.nextInt();
        } while (opcion < 1 || opcion > 3);

        switch (opcion) {
            case 1:
                System.out.println("Recorrido BFS");
                System.out.print("Nodo de inicio: ");
                opcion = sc.nextInt();
                graph.BFS(opcion);
                menuRecorrido(graph);
                break;
            case 2:
                System.out.println("Recorrido DFS");
                System.out.print("Nodo de inicio: ");
                opcion = sc.nextInt();
                graph.DFS(opcion);
                menuRecorrido(graph);
                break;
            case 3:
                System.out.println("Saliendo...");
                break;
        }
    }

    private static void menuRecorridoPonderado(GraphPonderado graph){
        int opcion = 0;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Menu:");
            System.out.println("1.- Aplicar algoritmo de Prim");
            System.out.println("2.- No aplicar algoritmo de Prim");
            System.out.print("opcion: ");
            opcion = sc.nextInt();
        } while (opcion < 1 || opcion > 2);

        if (opcion == 1) {
            System.out.println("Algoritmo de Prim");
            System.out.print("Nodo de inicio: ");
            opcion = sc.nextInt();
            graph.primm(opcion);
            menuRecorridoPonderado(graph);
        } else {
            System.out.println("Saliendo...");
        }
    }

    private static Graph crearGraph(int tipo) { // 1 no dirigido, 2 dirigido
        Scanner sc = new Scanner(System.in);
        int V;
        System.out.print("Numero de nodos: ");
        V = sc.nextInt();
        int v1, v2;
        Graph graph = new Graph(V);
        System.out.println("Para dejar de agregar nodos ingresa -1 como nodo inicial ");
        do {
            System.out.print("nodo de inicio: ");
            v1 = sc.nextInt();
            if (v1 == -1)
                return graph;
            System.out.print("nodo de llegada: ");
            v2 = sc.nextInt();
            if (tipo == 1)
                graph.addEdge(v1, v2);
            else
                graph.addEdgeDirigido(v1, v2);
        } while (true);
    }

    private static GraphPonderado crearGraphPonderado() { // 1 no dirigido, 2 dirigido
        Scanner sc = new Scanner(System.in);
        int V;
        System.out.print("Numero de nodos: ");
        V = sc.nextInt();
        int v1, v2, peso;
        GraphPonderado graph = new GraphPonderado(V);
        System.out.println("Para dejar de agregar nodos ingresa -1 como nodo inicial ");
        do {
            System.out.print("Nodo de inicio: ");
            v1 = sc.nextInt();
            if (v1 == -1)
                return graph;
            System.out.print("Nodo de llegada: ");
            v2 = sc.nextInt();
            System.out.print("Peso: ");
            peso = sc.nextInt();
            graph.addEdge(v1, v2, peso);
        } while (true);
    }

}
